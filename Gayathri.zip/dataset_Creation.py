#!/usr/bin/env python
# coding: utf-8

# In[488]:


names_of_employees = ["Harry", "Mike", "Jessie", "Tom", "Mary", "Ruther", "Chervy", "Miller", "Henry", "Ron", "Schaefer", "Hess", "Rich", "Valenzuela", "Moyer", "Morgan", "Bridges", "Buckley", "Bradford", "Gallegos", "Crosby", "Lloyd", "Fleming", "Warner", "Li", "Ashley", "Curry", "Blanchard", "Brooks", "Valentine", "Donovan", "Ford", "Duarte", "Stout", "Gaines", "Flynn", "Kim", "Stein", "Freeman", "Oconnor", "Potts", "Hogan", "Conway", "Serrano", "Charles", "Jennings", "Cox", "Caldwell", "Webster", "Clarke", "Conley", "Schmitt", "Mccoy", "Booker", "York", "Esparza", "Day", "Warren", "Lawson", "Ritter", "Bright", "Rice", "Best", "Gilbert", "Sims", "Meadows", "Krueger", "Carr", "Klein", "Mcgrath", "Donaldson", "Hebert", "Bruce"]
names_of_states = [ "Alabama",
     "Alaska",
    "American Samoa",
     "Arizona",
     "Arkansas",
     "California",
     "Colorado",
     "Connecticut",
     "Delaware",
     "District Of Columbia",
     "Federated States Of Micronesia",
     "Florida",
     "Georgia",
     "Guam",
     "Hawaii",
     "Idaho",
    "Illinois",
     "Indiana",
     "Iowa",
     "Kansas",
     "Kentucky",
     "Louisiana",
     "Maine",
     "Marshall Islands",
     "Maryland",
     "Massachusetts",
     "Michigan",
     "Minnesota",
     "Mississippi",
     "Missouri",
     "Montana",
     "Nebraska",
     "Nevada",
     "New Hampshire",
     "New Jersey",
     "New Mexico",
     "New York",
     "North Carolina",
     "North Dakota",
     "Northern Mariana Islands",
     "Ohio",
     "Oklahoma",
     "Oregon",
     "Palau",
     "Pennsylvania",
     "Puerto Rico",
     "Rhode Island",
     "South Carolina",
    "South Dakota",
     "Tennessee",
     "Texas",
     "Utah",
     "Vermont",
     "Virgin Islands",
     "Virginia",
     "Washington",
     "West Virginia",
     "Wisconsin",
     "Wyoming"]
food_list = ["chicken", "potatoes", "shrimp", "fish","tomatoes", "apple", "apricot",
        "avocado",
        "banana",
        "bell pepper",
        "bilberry",
        "blackberry",
        "blackcurrant",
        "blood orange",
        "blueberry",
        "boysenberry",
        "breadfruit",
        "canary melon",
        "cantaloupe",
        "cherimoya",
        "cherry",
        "chili pepper",
        "clementine",
        "cloudberry",
        "coconut",
        "cranberry",
        "cucumber",
        "currant",
        "damson",
        "date",
        "dragonfruit",
        "durian",
        "eggplant",
        "elderberry",
        "feijoa",
        "fig",
        "goji berry",
        "gooseberry",
        "grape",
        "grapefruit",
        "guava",
        "honeydew",
        "huckleberry",
        "jackfruit",
        "jambul",
        "jujube",
        "kiwi fruit",
        "kumquat",
        "lemon",
        "lime",
        "loquat",
        "lychee",
        "mandarine",
        "mango",
        "mulberry",
        "nectarine",
        "nut",
        "olive",
        "orange",
        "pamelo",
        "papaya",
        "passionfruit",
        "peach",
        "pear",
        "persimmon",
        "physalis",
        "pineapple",
        "plum",
        "pomegranate",
        "pomelo",
        "purple mangosteen",
        "quince",
        "raisin",
        "rambutan",
        "raspberry",
        "redcurrant",
        "rock melon",
        "salal berry",
        "satsuma",
        "star fruit",
        "strawberry",
        "tamarillo",
        "tangerine",
        "tomato",
        "ugli fruit",
        "watermelon"]
names_of_universities = []


# In[489]:


from random import randint
import random


# In[490]:


list_of_jsonObjects = []


def replace_parameters(template,parameters):
    for i in parameters:
        k = template.find("$",0,len(template))
        if k!=-1: 
            template = template[:k]+i+template[k+2:]
    return template


# In[491]:


template_1 = "Salary of a factory employee in $1 for 1 day = $2 It is given that $3 works for $4  months in the factory. Number of days in a month be 30. What is the salary of $5 in $6 months?"
i = 5
while i>0:
    d = {}
    num_of_months = randint(1,12)
    state = random.choice(names_of_states)
    names = random.choice(names_of_employees)
    salary = randint(1,10)

    d["answer"] = salary*num_of_months*30

    
    salary = str(salary)
    num_of_months = str(num_of_months)
    
    parameters = [state, salary, names, num_of_months, names, num_of_months ]
    d["question"] = replace_parameters(template_1, parameters)
    d["options"] = [salary, salary*2, 0]
    
    list_of_jsonObjects.append(d)
    
    i -= 1


# In[492]:


template_2 = "Price of one litre of milk = Rs 9 We know that the cow gives $1 litre of milk in one month. Price of $2 litres of milk in $3 months ?"
i = 5
while i>0:
    d = {}
    num_of_months = randint(1,12)
    
    num_of_litres = randint(1,50)
    

    price = num_of_litres*9*num_of_months

    d["answer"] = price
    
    num_of_months= str(num_of_months)
    num_of_litres= str(num_of_litres)
    price=str(price)
    
    parameters = [num_of_litres,num_of_litres, num_of_months, price]
    d["question"] = replace_parameters(template_2, parameters)
    d["options"] = [price, price*2, price*3,1000]
    
    list_of_jsonObjects.append(d)
    
    i -= 1


# In[493]:


template_3 = "$1 has Rs $2 with him. He wants to buy $3. One kg of $4 costs Rs $5. How many kgs of $6 can he buy?"
i = 5
while i>0:
    d = {}
    names = random.choice(names_of_employees)
    num_of_kgs = randint(1,50)
    price = randint(15,50)
    amount = randint(0,50)
    food_items = random.choice(food_list)
    
    answer = amount/price
    d["answer"] = amount/price
    
    num_of_kgs= str(num_of_kgs)
    price = str(price)
    amount = str(amount)

    
    parameters = [names,amount,food_items, food_items, price,food_items]
    d["question"] = replace_parameters(template_3, parameters)
    d["options"] = [answer, answer*2, answer*3,1000]
    
    list_of_jsonObjects.append(d)
    
    i -= 1


# In[494]:


template_4 = "$1 students from $2 State went on a camping trip. Each tent can accomodate a group of $3 students.How many tents are needed?"
i = 5
while i>0:
    d = {}
    state = random.choice(names_of_states)
    num_of_students = randint(1000,5000)
    tent_capacity = randint(2,8)
        
    answer = num_of_students/tent_capacity
    d["answer"] = int(answer)
    
    students= str(num_of_students)
    tent_cap = str(tent_capacity)

    
    parameters = [students,state,tent_cap]
    d["question"] = replace_parameters(template_4, parameters)
    d["options"] = [int(answer), int(answer)*2, int(answer)*3,100]
    
    list_of_jsonObjects.append(d)
    
    i -= 1


# In[495]:


template_5 = "A foodcourt owner has $1 $2. He puts them in delivery boxes. Each box can accomodate $3 food items. How many delivery boxes does he need?"
i = 5
while i>0:
    d = {}
    num_of_fooditems = randint(100,500)
    fooditem= random.choice(food_list)
    box_capacity = randint(30,100)
        
    answer = num_of_fooditems/box_capacity
    d["answer"] = int(answer)
    
    numfooditems= str(num_of_fooditems)
    box_cap = str(box_capacity)

    
    parameters = [numfooditems,fooditem,box_cap]
    d["question"] = replace_parameters(template_5, parameters)
    d["options"] = [int(answer), int(answer)*2, int(answer)*3,100]
    
    list_of_jsonObjects.append(d)
    
    i -= 1


# In[496]:


template_6 = "$1 's father has taken a loan for farming and has to pay $2 every month to repay the loan. He looks after $3 hens of his village for which he will be paid $4 for each per day. Now he earns $5*$6*30 per month. Does he earn enough amount every month that helps him repay the loan?"
i = 5
while i>0:
    d = {}
    to_pay = randint(5000,10000)
    names= random.choice(names_of_employees)
    num_of_hens = randint(10,40)
    payperhen_perday = randint(1,10)
        
    amount = num_of_hens*payperhen_perday*30
    if amount >= to_pay : d["answer"] = "YES" 
    else :  d["answer"] = "NO"  

    to_pay= str(to_pay)
    num_of_hens = str(num_of_hens)
    payperhen_perday = str(payperhen_perday)

    
    parameters = [names,to_pay,num_of_hens,payperhen_perday, num_of_hens, payperhen_perday]
    d["question"] = replace_parameters(template_6, parameters)
    d["options"] = ["YES", "NO"]
    
    list_of_jsonObjects.append(d)
    
    i -= 1


# In[497]:


template_7 = "$1 took a debt from his relative to buy a phone for Rs $2. He is expected to pay it back in equal amounts every month for $3 months. How much amount does he have to pay per month?"
i = 5
while i>0:
    d = {}
    to_pay = randint(5000,10000)
    names= random.choice(names_of_employees)
    num_of_months = randint(1,12)
        
    topay_permonth = to_pay/num_of_months
    
    d["answer"] = topay_permonth
 

    to_pay= str(to_pay)
    num_of_months= str(num_of_months)

    
    parameters = [names,to_pay,num_of_months]
    d["question"] = replace_parameters(template_7, parameters)
    d["options"] = [30000, topay_permonth, topay_permonth*2, 0]
    
    list_of_jsonObjects.append(d)
    
    i -= 1


# In[498]:


template_8 = "$1 bought a phone which costed $2 dollars. Life of a phone battery is $3 hours. On using it daily 24/7 , how many days does the battery last?"
i = 5
while i>0:
    d = {}
    price = randint(5000,10000)
    names= random.choice(names_of_employees)
    battery_life = randint(500,1000)
        
    num_of_days = battery_life/24
    
    d["answer"] = int(num_of_days)
 

    battery_life= str(battery_life)
    price= str(price)

    
    parameters = [names,price,battery_life]
    d["question"] = replace_parameters(template_8, parameters)
    d["options"] = [2, int(num_of_days), int(num_of_days)*2, 0]
    
    list_of_jsonObjects.append(d)
    
    i -= 1


# In[499]:


template_9 = "If $1 buckets can be filled with one tank full of water with $2 liters. How many buckets can we fill with water of $3 tanks?"
i = 5
while i>0:
    d = {}
    fillednum_of_buckets = randint(10,50)
    tank_cap = randint(500,1000)
    num_of_tanks = randint(10,30)
        
      
    answer = fillednum_of_buckets*num_of_tanks
    
    d["answer"] = int(answer)
 

    fillednum_of_buckets= str(fillednum_of_buckets)
    tank_cap= str(tank_cap)
    num_of_tanks= str(num_of_tanks)

    
    parameters = [fillednum_of_buckets,tank_cap,num_of_tanks]
    d["question"] = replace_parameters(template_9, parameters)
    d["options"] = [2, int(answer), int(answer)*2, 0]
    
    list_of_jsonObjects.append(d)
    
    i -= 1


# In[500]:


template_10 = "Government is helping farmers buy a cow by paying $1 dollars of its actual cost which is $2 dollars. If the farmers in the state bought around $3 cows. How much did the farmers save on the cows?"
i = 5
while i>0:
    d = {}
    govt_payment = randint(100,500)
    actual_cost = randint(600,1000)
    num_of_cows = randint(20,70)
        
      
    answer = govt_payment*num_of_cows
    
    d["answer"] = int(answer)
 

    govt_payment= str(govt_payment)
    actual_cost= str(actual_cost)
    num_of_cows= str(num_of_cows)

    
    parameters = [govt_payment,actual_cost,num_of_cows]
    d["question"] = replace_parameters(template_10, parameters)
    d["options"] = [2, int(answer), int(answer)*2, 0]
    
    list_of_jsonObjects.append(d)
    
    i -= 1


# In[501]:


template_11 = "A tiger consumes $1 kg of meat in a day. $2 's family consumes $3 kg meat a day. How many days in which $4 's family can consume $5 meat?"
i = 5
while i>0:
    d = {}
    tiger_cap = randint(10,20)
    family_cap = randint(1,5)
    names = random.choice(names_of_employees)
        
      
    answer = tiger_cap/family_cap
    
    d["answer"] = answer
 

    tiger_cap= str(tiger_cap)
    family_cap= str(family_cap)

    
    parameters = [tiger_cap,names,family_cap, names,tiger_cap ]
    d["question"] = replace_parameters(template_11, parameters)
    d["options"] = [2, answer, answer*2, 0]
    
    list_of_jsonObjects.append(d)
    
    i -= 1


# In[502]:


template_12 = "$1 bought 3 square fields A,B,C with sides being $2 meters, $3 meters, $4 meters respectively. What is the total area he owns?"
i = 5
while i>0:
    d = {}
    sideA = randint(10,20)
    sideB = randint(5,15)
    sideC = randint(20,40)

    names = random.choice(names_of_employees)
        
    AreaA = sideA*sideA
    AreaB = sideB*sideB
    AreaC = sideC*sideC
    
    Total_area = AreaA + AreaB + AreaC

    
    d["answer"] = Total_area
 

    sideA= str(sideA)
    sideB= str(sideB)
    sideC= str(sideC)

    
    parameters = [names,sideA,sideB,sideC]
    d["question"] = replace_parameters(template_12, parameters)
    d["options"] = [1034.5, Total_area, Total_area*2, 0]
    
    list_of_jsonObjects.append(d)
    
    i -= 1


# In[503]:


import json 
with open('data.json','w',encoding = 'utf-8') as f:
    json.dump(list_of_jsonObjects,f,ensure_ascii=False,indent = 4)

